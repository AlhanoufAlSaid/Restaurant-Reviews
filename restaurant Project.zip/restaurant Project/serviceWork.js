// Add version number for updating
const cacheName = 'restaurant-v1';
// cache files:
const cacheAssets = [
	'./',
	'./js/main.js',
	'./index.html',
	'./restaurant.html',
	'./data/restaurants.json',
	'./css/styles.css',
	'./js/dbhelper.js',
	'./js/restaurant_info.js',
	'./img/1.jpg',
	'./img/2.jpg',
	'./img/2.jpg',
	'./img/4.jpg',
	'./img/5.jpg',
	'./img/6.jpg',
	'./img/7.jpg',
	'./img/8.jpg',
	'./img/9.jpg',
	'./img/10.jpg'];

/*   Open a cache and cache needed assets   */
self.addEventListener('install', function (evt) {
	evt.waitUntil(
		caches
		.open(cacheName)
		.then((cache) => {
			console.log('Service Worker: Caching Assets');
			return cache.addAll(cacheAssets);
		})
	);
});

/* Remove caches */
self.addEventListener('activate', function (evt) {
	evt.waitUntil(
		caches
		.keys()
		.then((cacheNames) => {
			return Promise.all(
				cacheNames.filter(function (thisCacheName) {
					return cacheName.startsWith('restaurant-') &&
						thisCacheName != cacheName;
						console.log('Service Working: Removing Outdated Caches from', thisCacheName );
				})
				.map(function (cacheName) {
					return caches.delete(cacheName);
				})
			);
		})
	);
});

/* Respond to requests */
self.addEventListener('fetch', (evt) => {
	evt.respondWith(
		caches.match(evt.request)
		.then((response) => {
			// Return cached 
			return response || fetch(evt.request);
		})
	);
})

/*
  Resources used to build service worker:
  https://www.youtube.com/watch?v=TxXwlOAXUko
  https://developers.google.com/web/ilt/pwa/caching-files-with-service-worker
  https://www.youtube.com/watch?v=BfL3pprhnms&t=449s
*/
